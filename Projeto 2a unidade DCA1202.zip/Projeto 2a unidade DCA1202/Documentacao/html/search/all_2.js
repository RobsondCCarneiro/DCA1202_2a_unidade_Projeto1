var searchData=
[
  ['getx',['getX',['../class_point.html#a9aa94b8fd07296e64d304ef3750db113',1,'Point']]],
  ['gety',['getY',['../class_point.html#a2444daa96871c89614510bc4bfcd19ce',1,'Point']]]
];
