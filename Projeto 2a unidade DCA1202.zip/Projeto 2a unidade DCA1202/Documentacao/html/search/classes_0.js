var searchData=
[
  ['point',['Point',['../class_point.html',1,'']]],
  ['poligono',['Poligono',['../class_poligono.html',1,'']]]
];
