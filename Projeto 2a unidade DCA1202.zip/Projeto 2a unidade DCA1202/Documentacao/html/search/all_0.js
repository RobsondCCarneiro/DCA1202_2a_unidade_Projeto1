var searchData=
[
  ['add',['add',['../class_point.html#a34e2dba7c7e6df1a3a90dd41d2797fc5',1,'Point']]],
  ['areapoligono',['areaPoligono',['../class_poligono.html#ac1e37e274f61dff6c421f972ef1cf891',1,'Poligono']]]
];
