var searchData=
[
  ['norma',['norma',['../class_point.html#aa3005a9d97e2cb05624414973a214788',1,'Point']]]
];
