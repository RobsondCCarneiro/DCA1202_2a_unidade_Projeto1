var searchData=
[
  ['qtdevertice',['qtdeVertice',['../class_poligono.html#a34a352799b80701082ade986164f2ba7',1,'Poligono']]]
];
