var searchData=
[
  ['translada',['translada',['../class_point.html#ad9676e36f3444534b609e3c68422239a',1,'Point']]],
  ['transladapoligono',['transladaPoligono',['../class_poligono.html#a4d757f52ba9366ab13537fb19b363e1e',1,'Poligono']]]
];
