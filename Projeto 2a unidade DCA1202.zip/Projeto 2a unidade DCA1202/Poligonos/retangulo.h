#ifndef RETANGULO_H
#define RETANGULO_H

#include "poligono.h"
#include <iostream>
#include <cmath>
class Retangulo: public Poligono{
public:
    Retangulo(float _x, float _y, float l, float h);
};

#endif // RETANGULO_H
